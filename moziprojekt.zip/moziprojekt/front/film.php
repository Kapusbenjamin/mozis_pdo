<!DOCTYPE html>
<html>
<head>  
<script>
function showFilm(str) {
    if (str == "") {
        document.getElementById("txtHint").innerHTML = "";
        return;
    } else {
        if (window.XMLHttpRequest) {
            xmlhttp = new XMLHttpRequest();
        } else {
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","../back/getfilms.php?szoveg="+str,true);
        xmlhttp.send();
    }
}
</script>
</head>
<body>
	<div>
	<form method="post">
	<p>Válasszon filmet!</p>
<select name='film' onchange='showFilm(this.value)'>
<option value=""></option>
<?php
require_once "../back/conn.php";

	$database = $conn->prepare("SELECT * FROM film");
	$database->execute();
	$result = $database->fetchAll();
	
	foreach($result as $film){
		echo "<option value='{$film['id']}'>{$film['cim']}</option>";
	}
?>
  </select>
<br>
<p id="txtHint"><b>Az információk itt lesznek leírva:</b></p>

	<h3>Írja be mennyi jegyet szeretne vásárolni:</h3>
	<input type='number' name='helyfoglalas'></input>

	<inpuT type='submit' name='gomb' value='Ok'></input>
	</form>
	</div>
	
	
</body>

</html>
<?php
session_start();

	if(strlen($_SESSION['hiba']) == 4){
		echo "Hiba! Nincs elég szabad hely!";
	}
	elseif(strlen($_SESSION['hiba']) == 9){
		echo "A jegyek elfogytak!";
	}
	else{
		echo "";
	}

	
if(isset($_POST['gomb'])){
	$_SESSION['foglalt_film_neve'] = $_POST['film'];
	$_SESSION['foglalt_jegyek'] = $_POST['helyfoglalas'];
	header("Location: ../back/end.php");
}


?>
