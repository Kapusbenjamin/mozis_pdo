<?php
session_start();
require_once "conn.php";
$_SESSION['hiba'] = 'false';

if(isset($_POST["register"])){
	
	if($_POST["psw"] == $_POST["psw-repeat"]){
		
		$username = strip_tags(trim($_POST["username"]));
		$email = strip_tags(trim($_POST["email"]));
		$password = strip_tags(trim($_POST["psw"]));
		$password_repeat = strip_tags(trim($_POST["psw-repeat"]));
		
		echo $username;
		
		if(filter_var($email, FILTER_VALIDATE_EMAIL)){
		
			$sql = $conn->prepare("INSERT INTO users(username, email, password) VALUES(:username, :email, :psw)");
			$sql->bindParam(':username', $username);
			$sql->bindParam(':email', $email);
			$sql->bindParam(':psw', $password);
			$sql->execute();
			
			$adatok = $conn->prepare("SELECT * FROM users WHERE username=:username AND email=:email");
			$adatok->bindParam(':username', $username);
			$adatok->bindParam(':email', $email);
			$adatok->execute();
			
			foreach($adatok as $id){
				$_SESSION['id'] = $id['id'];
			}
			echo $_SESSION['id'];
			header("Location: ../front/film.php");
		}
		else{
			echo "Az E-mail nem megfelelő formátumú!";
		}
	}
	else{
		echo "Nem egyezik meg a jelszó!";
	}
}






?>