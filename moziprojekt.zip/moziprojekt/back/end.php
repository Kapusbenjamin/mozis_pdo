<?php
session_start();
require_once "conn.php";

	$film_id = $_SESSION['foglalt_film_neve'];
 	$helyfoglalas = $_SESSION['foglalt_jegyek'];
	
	$result = $conn->prepare("SELECT * FROM film WHERE id='{$film_id}'");
	$result->execute();
	

	foreach($result as $film){
	}	

	if($film['szabadhely'] >= $helyfoglalas && $film['szabadhely'] > 0 && $helyfoglalas != 0){
		$frissites = $conn->prepare("UPDATE users SET foglalt_film_neve=:filmcim, foglalt_jegyek=:helyfoglalas WHERE id=:id");
		$frissites->bindParam(':filmcim', $film['cim']);
		$frissites->bindParam(':helyfoglalas', $helyfoglalas);
		$frissites->bindParam(':id', $_SESSION['id']);
		$frissites->execute();

		$szabadhely = $film['szabadhely']-$helyfoglalas;
		$helyfrissites = $conn->prepare("UPDATE film SET szabadhely=:szabadhely WHERE id='{$film_id}'");
		$helyfrissites->bindParam(':szabadhely', $szabadhely);
		$helyfrissites->execute();
		
		$_SESSION['foglaltfilmcim'] = $film['cim'];
		
		$_SESSION['jegyar'] = $film['jegyar'];
		header("Location: ../front/vasarlas.php");
	}
	elseif($film['szabadhely'] == 0){
		$_SESSION['hiba'] = 'elfogyott';
		header("Location: ../front/film.php");
	}
	else{
		$_SESSION['hiba'] = 'true';
		header("Location: ../front/film.php");
	}


		

?>