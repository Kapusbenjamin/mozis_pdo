<?php
	session_start();
	
		echo "Sikeres vásárlás!";
		echo "<br>";
		echo $_SESSION['foglalt_jegyek'] . " jegyet foglalt a " . $_SESSION['foglaltfilmcim'] . " filmre.";
		echo "<br>";
		echo "A vásárlás összesen " . $_SESSION['jegyar']*$_SESSION['foglalt_jegyek'] . " Forintba került.";



?>