<?php
require_once "conn.php";

$szoveg = intval($_GET['szoveg']);

$database = $conn->prepare("SELECT * FROM film WHERE id='{$szoveg}'");
$database->execute();
$result = $database->fetchAll();
	

echo "<table>
<tr>
<th>Cím</th>
<th>Jegy ára (Ft/darab)</th>
</tr>";
foreach($result as $film) {
    echo "<tr>";
    echo "<td>" . $film['cim'] . "</td>";
    echo "<td align='center'>" . $film['jegyar'] . "</td>";
    echo "</tr>";
}
echo "</table>";

?>
