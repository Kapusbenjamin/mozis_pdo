<?php
echo "
<!DOCTYPE html>
<html>
	<head>   <meta charset='UTF-8'>
	</head>
	<body>
		<form action='../back/register.php' method='post'>
			<div>
				<h1>Regisztrálás</h1>
				<p>Töltse ki a mezőket a regisztráláshoz!.</p>
				<hr>
			
				<input type='text' placeholder='Felhasználónév' name='username' required>
				<input type='text' placeholder='Email' name='email' required>
				<input type='password' placeholder='Jelszó' name='psw' required>
				<input type='password' placeholder='Jelszó újra' name='psw-repeat' required>
				<hr>

				<button type='submit' name='register'>Regisztrálás</button>
			</div>
	</body>
</html>
";
session_start();
$_SESSION['hiba'] = 'false';
?>